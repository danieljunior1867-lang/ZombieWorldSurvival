Zombie World: Survival — Android Project

ဒီ ZIP က APK မဟုတ်သေးပါ။ GitHub Actions cloud build workflow ပါဝင်တဲ့ Android Studio project ဖြစ်ပါတယ်။

ဖုန်းကနေ APK ထုတ်ရန်:
1. ZIP ကို Extract လုပ်ပါ။
2. GitHub account ဖြင့် github.com ကို Chrome မှာဝင်ပါ။
3. New repository တစ်ခုဖန်တီးပါ (ဥပမာ ZombieWorldSurvival)။
4. Add file > Upload files ကိုနှိပ်ပြီး Extract လုပ်ထားတဲ့ folder ထဲက ဖိုင်/ဖိုလ်ဒါအားလုံးကို upload လုပ်ပါ။ .github folder လည်း ပါရပါမယ်။
5. Commit changes လုပ်ပါ။
6. Repository ထဲက Actions tab ကိုဖွင့်ပါ။
7. "Build Zombie World APK" workflow ကိုရွေးပြီး Run workflow နှိပ်ပါ။
8. Build အောင်မြင်လျှင် workflow run အောက်ဆုံး Artifacts မှ ZombieWorldSurvival-debug-apk ကို download လုပ်ပါ။
9. ZIP artifact ကို extract လုပ်ပြီး app-debug.apk ကိုနှိပ်၍ install လုပ်ပါ။

သတိ:
- GitHub account လိုအပ်နိုင်ပြီး repository ကို Private ထားရန် အကြံပြုပါတယ်။
- ဒီ Project ကို Android SDK ဖြင့် compile/test မလုပ်ရသေးပါ။ Build အမှားရှိပါက Actions log ကိုကြည့်ပြီး ပြင်ဆင်ရန်လိုနိုင်ပါတယ်။
- APK သည် debug APK ဖြစ်ပြီး Play Store တင်ရန် production signing မပါဝင်ပါ။
